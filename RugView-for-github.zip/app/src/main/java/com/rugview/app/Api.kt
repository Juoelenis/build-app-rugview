package com.rugview.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/** All endpoints live here. Docs: GET https://rugplay.com/api/v1/... with "Authorization: Bearer rgpl_..." */
object Api {
    const val BASE = "https://rugplay.com/api/v1"
    private val client = OkHttpClient()

    class ApiException(msg: String) : Exception(msg)

    suspend fun get(path: String, key: String): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(BASE + path)
            .header("Authorization", "Bearer $key").build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(
                when (r.code) {
                    400 -> "Bad request (invalid parameters)"
                    401 -> "Invalid or missing API key"
                    404 -> "Not found"
                    429 -> "Rate limit hit (2,000 requests/day)"
                    else -> "Server error (HTTP ${r.code})"
                }
            )
            JSONObject(body)
        }
    }
}
