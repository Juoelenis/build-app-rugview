package com.rugview.app

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import org.json.JSONObject

private val Green = Color(0xFF2ECC71)
private val Red = Color(0xFFE74C3C)

class KeyStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("rugview", Context.MODE_PRIVATE)
    var key: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v.trim()).apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = KeyStore(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App(store) } } }
    }
}

fun fmt(d: Double): String = when {
    d >= 1e12 -> "%.2fT".format(d / 1e12)
    d >= 1e9 -> "%.2fB".format(d / 1e9)
    d >= 1e6 -> "%.2fM".format(d / 1e6)
    d >= 1e3 -> "%.2fK".format(d / 1e3)
    d >= 1 -> "%.2f".format(d)
    else -> "%.6f".format(d)
}

@Composable
fun App(store: KeyStore) {
    var key by remember { mutableStateOf(store.key) }
    var tab by remember { mutableStateOf(if (key.isBlank()) 3 else 0) }
    var selected by remember { mutableStateOf<String?>(null) }
    val items = listOf("Market" to Icons.Default.Home, "Hopium" to Icons.Default.Star,
        "Trade" to Icons.Default.ShoppingCart, "Key" to Icons.Default.Settings)
    Scaffold(bottomBar = {
        NavigationBar {
            items.forEachIndexed { i, (label, icon) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i; selected = null },
                    icon = { Icon(icon, null) }, label = { Text(label) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                tab == 2 -> TradeWeb()
                tab == 3 -> KeyScreen(key) { key = it; store.key = it; tab = 0 }
                key.isBlank() -> Text("Add your API key in the Key tab.", Modifier.padding(16.dp))
                tab == 0 && selected != null -> CoinDetail(selected!!, key) { selected = null }
                tab == 0 -> MarketScreen(key) { selected = it }
                tab == 1 -> HopiumScreen(key)
            }
        }
    }
}

@Composable
fun <T> Load(key: Any?, fetch: suspend () -> T, content: @Composable (T) -> Unit) {
    var state by remember(key) { mutableStateOf<Result<T>?>(null) }
    LaunchedEffect(key) { state = null; state = runCatching { fetch() } }
    val s = state
    when {
        s == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        s.isFailure -> Text("Error: ${s.exceptionOrNull()?.message}", Modifier.padding(16.dp), color = Red)
        else -> content(s.getOrThrow())
    }
}

@Composable
fun MarketScreen(key: String, onOpen: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var dq by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("marketCap") }
    LaunchedEffect(q) { delay(500); dq = q }
    Column {
        OutlinedTextField(q, { q = it }, label = { Text("Search name or symbol") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(8.dp))
        Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("marketCap" to "Cap", "change24h" to "24h %", "volume24h" to "Vol", "createdAt" to "New").forEach { (v, l) ->
                FilterChip(selected = sort == v, onClick = { sort = v }, label = { Text(l) })
            }
        }
        Load(listOf(dq, sort, key), { Api.get("/market?search=${Uri.encode(dq)}&sortBy=$sort&sortOrder=desc&limit=50", key) }) { j ->
            val arr = j.getJSONArray("coins")
            LazyColumn {
                items((0 until arr.length()).map { arr.getJSONObject(it) }) { c ->
                    val ch = c.optDouble("change24h")
                    Row(Modifier.fillMaxWidth().clickable { onOpen(c.getString("symbol")) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("*${c.getString("symbol")}", fontWeight = FontWeight.Bold)
                            Text("${c.optString("name")} · cap ${fmt(c.optDouble("marketCap"))}", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("$" + fmt(c.optDouble("currentPrice")))
                            Text("%.2f%%".format(ch), color = if (ch >= 0) Green else Red, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun CoinDetail(sym: String, key: String, onBack: () -> Unit) {
    Load(sym, {
        coroutineScope {
            val c = async { Api.get("/coin/$sym?timeframe=1h", key) }
            val h = async { Api.get("/holders/$sym?limit=10", key) }
            c.await() to h.await()
        }
    }) { (cj, hj) ->
        val coin = cj.getJSONObject("coin")
        val candles = cj.optJSONArray("candlestickData")
        val closes = (0 until (candles?.length() ?: 0)).map { candles!!.getJSONObject(it).getDouble("close") }
        val holders = hj.getJSONArray("holders")
        LazyColumn(Modifier.padding(12.dp)) {
            item {
                TextButton(onClick = onBack) { Text("← Back") }
                Text("*${coin.getString("symbol")} · ${coin.optString("name")}", style = MaterialTheme.typography.headlineSmall)
                Text("$" + fmt(coin.optDouble("currentPrice")), style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Chart(closes)
                Spacer(Modifier.height(8.dp))
                Stat("Market cap", "$" + fmt(coin.optDouble("marketCap")))
                Stat("24h volume", "$" + fmt(coin.optDouble("volume24h")))
                Stat("24h change", "%.2f%%".format(coin.optDouble("change24h")))
                Stat("Pool (coins)", fmt(coin.optDouble("poolCoinAmount")))
                Stat("Pool (base $)", fmt(coin.optDouble("poolBaseCurrencyAmount")))
                Stat("Circulating", fmt(coin.optDouble("circulatingSupply")))
                Stat("Creator", coin.optString("creatorName") + " (@" + coin.optString("creatorUsername") + ")")
                Spacer(Modifier.height(12.dp))
                Text("Top holders", fontWeight = FontWeight.Bold)
                Text("Big creator share = rug risk", style = MaterialTheme.typography.bodySmall)
            }
            items((0 until holders.length()).map { holders.getJSONObject(it) }) { h ->
                Stat("#${h.getInt("rank")} @${h.optString("username")}", "%.2f%%".format(h.optDouble("percentage")))
            }
        }
    }
}

@Composable
fun Stat(l: String, v: String) = Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(l, style = MaterialTheme.typography.bodyMedium); Text(v, fontWeight = FontWeight.Medium)
}

@Composable
fun Chart(v: List<Double>) {
    if (v.size < 2) { Text("No chart data"); return }
    val up = v.last() >= v.first()
    val mn = v.min(); val mx = v.max(); val range = (mx - mn).takeIf { it > 0 } ?: 1.0
    Canvas(Modifier.fillMaxWidth().height(160.dp)) {
        val path = Path()
        v.forEachIndexed { i, y ->
            val px = size.width * i / (v.size - 1)
            val py = size.height * (1f - ((y - mn) / range).toFloat())
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        drawPath(path, if (up) Green else Red, style = Stroke(width = 4f))
    }
}

@Composable
fun HopiumScreen(key: String) {
    Load(key, { Api.get("/hopium?status=ACTIVE&limit=50", key) }) { j ->
        val arr = j.getJSONArray("questions")
        LazyColumn(Modifier.padding(8.dp)) {
            items((0 until arr.length()).map { arr.getJSONObject(it) }) { q ->
                val yes = q.optDouble("yesPercentage").toFloat()
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(q.getString("question"), fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { yes / 100f }, Modifier.fillMaxWidth(), color = Green, trackColor = Red)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("YES %.1f%%".format(yes), color = Green, style = MaterialTheme.typography.bodySmall)
                            Text("pool $" + fmt(q.optDouble("totalAmount")), style = MaterialTheme.typography.bodySmall)
                            Text("NO %.1f%%".format(100 - yes), color = Red, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TradeWeb() {
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://rugplay.com/")
        }
    })
}

@Composable
fun KeyScreen(current: String, onSave: (String) -> Unit) {
    var k by remember { mutableStateOf(current) }
    Column(Modifier.padding(16.dp)) {
        Text("Rugplay API key", style = MaterialTheme.typography.titleMedium)
        Text("Starts with rgpl_. Stored only on this device. Limit: 2,000 requests/day.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(k, { k = it }, singleLine = true, label = { Text("rgpl_...") }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
        Button(onClick = { onSave(k) }, enabled = k.isNotBlank()) { Text("Save") }
    }
}
